// oppgave 1
// Statisk tekst som brukes til å søke i
const tt =
  "Baby cliche unicorn brooklyn farm-to-table. Salvia semiotics hella literally paleo humblebrag bushwick letterpress messenger bag pork belly brooklyn authentic vexillologist. Gastropub sustainable banjo, shaman snackwave viral air plant ramps health goth. Edison bulb vegan microdosing, tote bag unicorn skateboard disrupt copper mug four loko sustainable whatever cloud bread slow-carb lumbersexual four dollar toast. Waistcoat lomo hammock vape shabby chic sartorial yr godard pok pok fashion axe organic migas. Quinoa yr vexillologist intelligentsia verylongwordthatislong neutra mixtape YOLO XOXO listicle letterpress farm-to-table beard.";

const longestWord = () => {
  let textword = tt.split(" ");

  let longestWord = textword[0];

  for (let i = 0; i < textword.length; i++) {
    if (longestWord.length < textword[i].length) {
      longestWord = textword[i];
    }
  }
  return longestWord;
};

console.log(longestWord());

// oppgave 0
// Oppgave 1
const t = document.getElementById("remove");
const removebtn = document.getElementById("remove-btn");
const removetxt = () => {
  t.innerHTML = "";
};
removebtn.addEventListener("click", removetxt);
// Oppgave 2
const changer = document.getElementById("change");
const changeBtn = document.getElementById("change-btn");
const changeTxt = () => {
  changer.innerHTML = "dooty booty";
};
changeBtn.addEventListener("click", changeTxt);

// Oppgave 3
const inputTxt = document.getElementById("input-text");
const input = document.getElementById("input");

// starter med å fjerne teksten som allerede ligger der
const removeTxt = () => {
  inputTxt.innerHTML = "";
};

// caller på funksjonen sånn at teksten blir fjernet
removeTxt();

/*her lager jeg function som skal oppdatere 
 teksten som ble fjernet med alt jeg typer inn i inputtext  
*/
const updateTxt = (action) => {
  var txt = action.key;
  inputTxt.innerHTML += txt;
};
/*her lager jeg en eventlistner som oppstår når du presser tastaturet
da vil funksjonen updatxt kjøre og teksten kommer ut på inputTxt*/
input.addEventListener("keydown", updateTxt);

// Oppgave 4
const myList = ["item one", "item two", "item three"];
const ul = document.getElementById("ul");
const listbtn = document.getElementById("write-list");
const createLi = () => {
  myList.forEach((listElement) => (ul.innerHTML += `<li>${listElement}</li>`));
};

listbtn.addEventListener("click", createLi);

// Oppgave 5

const text = document.getElementById("text");
const createBtn = document.getElementById("create");
const select = document.getElementById("select");
const htmlPlaceHolder = document.getElementById("placeholder");

const createElement = () => {
  const htmlEl = select.value;
  const message = text.value;
  htmlPlaceHolder.innerHTML += `<${htmlEl}>${message}</${htmlEl}>`;
};

createBtn.addEventListener("click", createElement);

// Oppgave 6
//lastElementChild read-only property returns an element's last child Element, or null if there are no child elements.
const parentlist = document.getElementById("list");
const removeLiBtn = document.getElementById("remove-li");

const removeList = () => {
  const lastEl = parentlist.lastElementChild;
  if (lastEl) {
    parentlist.removeChild(lastEl);
  }
};

removeLiBtn.addEventListener("click", removeList);

// Oppgave 7

const inputWord = document.getElementById("name");
const rekkBtn = document.getElementById("order");

const makeborder = () => {
  const name = inputWord.value;

  if (name && name.length >= 4) {
    rekkBtn.style = "border: 5px solid red";
    rekkBtn.disabled = true;
  } else {
    rekkBtn.style = "border: 5px solid black";
    rekkBtn.disabled = false;
  }
};

inputWord.addEventListener("keydown", makeborder);

// Oppgave 8
//fikk hjelp fra studass
const ulParent = document.querySelector(".children");
const ulChildren = ulParent.querySelectorAll("li");
const fargeBtn = document.getElementById("color");
const lagborder = () => {
  Array.from(ulChildren).forEach((li, index) => {
    if ((index + 1) % 2 === 0) {
      li.style = "border: 1px solid green; margin-bottom: 10px; padding: 5px;";
    } else {
      li.style = "border: 1px solid pink; margin-bottom: 10px; padding: 5px;";
    }
  });
};

fargeBtn.addEventListener("click", lagborder);
