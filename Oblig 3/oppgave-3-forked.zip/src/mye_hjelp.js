import "./styles.css";

// TODO: Sett startverdien for de ulike tellerene
let wordCounter = 0;
let positionCounter = 0;
let wrongCounter = 0;

// TODO: Lag en liste med ulike ord
const words = ["jeg", "hater", "corona", "og", "jeg", "hater", "karantene"];

// TODO: Hent ut HTML #id og knappen
const word = document.getElementById("word");
const wrongs = document.getElementById("wrongs");
const letter = document.getElementById("letter");
const button = document.querySelector("button");

const setWord = () => {
  // TODO: Skriv ut ordet som brukeren skal skrive eller en medling om at det ikke er flere ord igjen
  // her skriver jeg ut current word brukeren må skrive og det som kommer når det er tom for ord å skrive
  // jeg bruker || or javascript operator på å velge mellom current word og meldingen
  let meldingen = "zzzzz ingen ord igjen zzzzz"
  if(true){
    word.innerHTML = words[wordCounter] || meldingen
  }
};

//changeword functionen endrer ordet som kommer ved at vi legger wordcounter fordi vi bytter til neste ord og
// vi starter på posisiton 0 av det neste ordet som kommer
const changeWord = () => {
  positionCounter = 0;
  wordCounter++;
  setWord();
};

// TODO: Sjekk vi har skrevet riktig bokstav. Må ta hensyn til plassen i ordet vi skal skrive
// her sjekker jeg om vi har skrevet riktig bokstav vi sammenligner med equality operator (===)for å sjekke 
// om neste bokstav er lik som den som står under. 
const checkPosition = (word, position, letter) => {
  let wordPosition = word[position];
  return wordPosition === letter;
};

// TODO: Sjekk om posisjonen vi er på er lik lengden på ordet vi skal skrive. Det betyr at vi er ferdig med ordet og kan bytte ord
//her sjekker jeg ved å bruke equal operator om ord lengeden er på lik lengde som 
//som posisjonen vi er på. 
const wordIsCorrect = (word, position) => {
  let wordLength = word.length;
  return position === wordLength;
};

const handleKeyUp = ({ key }) => {
  // TODO: Hent ut ordet vi skal skrive
  const word = words[wordCounter];
  // TODO: Bruk checkPosition() til å sjekke om vi har skrevet rett bokstav
  if (checkPosition(word, positionCounter, key)) {
    // TODO: Øk posisjonstelleren
    positionCounter++;
    // TODO: Bruk wordIsCorrect() til å sjekke om vi er ferdig med ordet
    if (wordIsCorrect(word, positionCounter)) {
      // TODO: Trigg funksjonen som bytter ord
      changeWord();
    }
  } else {
    // TODO: Oppdater telleren for "feil"
    wrongCounter++;
  }
  updateUI(key);
};

const updateUI = (key) => {
  if (words[wordCounter]) {
    wrongs.innerHTML = wrongCounter;
    letter.innerHTML = key;
    // jeg visste ikke hvordan jeg skulle gjøre om 
    //words[wordcounter] til grønn derfor byttet jeg til mye hjelp
    word.innerHTML = `<span class="green">${words[wordCounter].slice(
      0,
      positionCounter
    )}</span>${words[wordCounter].slice(positionCounter)}`;
  }
};

window.addEventListener("keyup", handleKeyUp);
button.addEventListener("click", () => {
  button.disabled = true;
  setWord();
});
