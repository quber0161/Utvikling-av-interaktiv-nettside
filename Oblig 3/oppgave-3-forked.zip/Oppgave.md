I denne oppgaven skal du så fort du klarer skrive ordet som dukker opp etter klikk på startknappen. Hvis du skriver feil bli antall feil oppdatert. Brukeren skal hele tiden se hvilken bokstav de har skrevet. Hvis de har skrevet riktig ord skal nytt ord dukke opp.

I denne oppgaven får du øvd på:

- hente ut HTML elementer basert på Id og type (querySelector)
- oppdatere grensesnittet (HTML) med template literals ``
- bruk av array og array-metoder
- bruk av string-metoder som indexOf
- bruk av conditionals (if / else)
- bruk av ===
- lytte til ulike events (keyup og click)
- lage og kombinere funksjoner
